<?php
namespace src\models;
use \core\Model;

class Birthday1 extends Model {

}