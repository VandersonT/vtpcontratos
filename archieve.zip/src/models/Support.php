<?php
namespace src\models;
use \core\Model;

class Support extends Model {

}