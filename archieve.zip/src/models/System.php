<?php
namespace src\models;
use \core\Model;

class System extends Model {

}