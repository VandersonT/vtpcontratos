<?php
namespace src\models;
use \core\Model;

class Wedding1 extends Model {

}