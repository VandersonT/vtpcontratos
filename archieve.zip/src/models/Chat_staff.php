<?php
namespace src\models;
use \core\Model;

class Chat_staff extends Model {

}