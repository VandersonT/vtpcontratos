<?php
namespace src\models;
use \core\Model;

class Devweb1 extends Model {

}